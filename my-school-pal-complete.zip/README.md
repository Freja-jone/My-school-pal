# My School Pal

A free, mobile-first web app prototype for Years 6–11.

## Publish it for free
1. Create/sign in to a GitHub account.
2. Create a **public** repository (for example `my-school-pal`).
3. Upload all files in this folder.
4. Open **Settings → Pages**.
5. Under "Build and deployment", choose **Deploy from a branch**.
6. Select `main` and `/ (root)`, then Save.
7. GitHub will give you a web address.

## Important
This is a prototype. It uses browser local storage for progress and diary entries. Before a public launch for children, complete safeguarding, privacy and UK data-protection review. Do not put secrets or sensitive personal information in the GitHub repository.
